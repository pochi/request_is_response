class UserIssueMonth < ActiveRecord::Base
  attr_accessible :uid, :issue, :odr
end
