require File.dirname(__FILE__) + '/../test_helper'

class WtMemberOrderTest < Test::Unit::TestCase
  fixtures :wt_member_orders

  # Replace this with your real tests.
  def test_truth
    assert true
  end
end
